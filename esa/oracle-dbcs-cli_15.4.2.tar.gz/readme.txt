Contents
--------
* Prerequisites.
* Usage Examples.
* Template File.

Prerequisites
-------------
* The Java version must be 1.7 or higher.
* The location of dborch.jar must be set in the PATH variable or in the same
  location as the execution.

Usage Examples 
--------------
To create a Virtual Machine:  
  To generate the dboplan.dat file refer to the "Template File" section. When
  the -nolaunch option is set, the machine is created but not submitted to the
  server.

  Commands:
    oracle-dbcs-cli create -dat dboplan.dat
    oracle-dbcs-cli create -dat dboplan.dat -nolaunch

  Example:
    $ oracle-dbcs-cli create -dat dboplan.dat 
    Database Cloud Orchestration Tool:Release 2.0.30.12.00 on Wed Feb 04
    10:25:18 PST 2015
    Copyright ©2014,2015, Oracle. All rights reserved.

    Creating VM
    .Done...
    DBOrch execution ended.

List the generated virtual machines:
  All the generated VMs can be displayed with the "list" action. Use the -vmname
  option to display the detailed information about that machine. Refer to
  "Template File" to generate file.cfg.

  Commands:
    oracle-dbcs-cli list -cfg file.cfg
    oracle-dbcs-cli list -cfg file.cfg -vmname name

  Example:
  $ oracle-dbcs-cli list -cfg file.cfg 
  Database Cloud Orchestration Tool:Release 2.0.30.12.00 on Wed Feb 04
  12:55:12 PST 2015
  Copyright ©2014,2015, Oracle. All rights reserved.

  name                                                                                          OCPUs: 1
  Version: 12.1.0.2                                 Date Created: Wed Feb 4 18:25:14 UTC 2015   Memory: 7.5 GB
  Edition: Enterprise Edition - High Performace                                                 

  DBOrch execution ended.
  
  $ oracle-dbcs-cli list -cfg file.cfg -vmname name
  Database Cloud Orchestration Tool:Release 2.0.30.12.00 on Wed Feb 04
  12:55:24 PST 2015
  Copyright ©2014,2015, Oracle. All rights reserved.

  Service Name:            name
  Oracle Database Version: 12.1.0.2
  Description:             name

  Nodes

  SQL *Net Port:           1521
  Public IP:               192.168.1.30
  SID:                     orcl
  PDB Name:                PDB1
  OCPUs:                   1
  Memory:                  7.5 GB
  Storage:                 81.00 GB

  Additional information

  Edition:                 Enterprise Edition - High Performace
  Level:                   PAAS
  Subscription Type:       HOURLY
  Created on:              Wed Feb 4 18:25:14 UTC 2015
  Created by:              weblogic
  Identity Domain:         Domain1
  Connect Descriptor:      name:1521/PDB1.opcdbaas.oraclecloud.internal
  Backup Destination:      DISK
  Enterprise Manager Url:  https://192.168.1.30:5500/em

  DBOrch execution ended.

Scale up a Virtual Machine:
  To increase the about of CPUs and Memory, the "scaleup" action is used. The
  options -shape, -cfg, -vmname are needed. Refer to "Template File" to generate
  file.cfg.

  Command:
    oracle-dbcs-cli scaleup -cfg file.cfg -shape <shape> -vmname <name>

  Example:
  $ oracle-dbcs-cli scaleup -shape oc3 -cfg file.cfg -vmname name
  Database Cloud Orchestration Tool:Release 2.0.30.12.00 on Wed Feb 04 14:48:09
  PST 2015
  Copyright ©2014,2015, Oracle. All rights reserved.

  DBOrch execution ended.

Destroy a Virtual Machine:
  Use the "delete" action to destroy a VM. The options -cfg, -vmname are needed.
  Refer to "Template File" to generate file.cfg.

  Command:
    oracle-dbcs-cli delete -cfg <file.cfg> -vmname <name>

  Example:
    $ oracle-dbcs-cli delete -cfg file.cfg -vmname name
    Database Cloud Orchestration Tool:Release 2.0.30.12.00 on Wed Feb 04 15:43:13
    PST 2015
    Copyright ©2014,2015, Oracle. All rights reserved.

    Deleted name
    DBOrch execution ended.

Patching:
  There are several subactions to patching:
    apply  Apply Patch to VM.
      -key     Private SSH-key file to the Virtual Machine.
      -secret  Pass phrase, if it exists in the VM.
      -host    IP of the Virtual Machine.
      -id      ID of the patch.
      -force   Ignores conflicts.

    check  Check if patch can be applied.
      -key     Private SSH-key file to the Virtual Machine.
      -secret  Pass phrase, if it exists in the VM.
      -host    IP of the Virtual Machine.
      -id      ID of the patch.
      -force   Ignores conflicts.

    rollback  Rollback Patch on VM.
      -key     Private SSH-key file to the Virtual Machine.
      -secret  Pass phrase, if it exists in the VM.
      -host    IP of the Virtual Machine.
      -id      ID of the patch.

    status    Get status of patch or conflict check.
      -key     Private SSH-key file to the Virtual Machine.
      -secret  Pass phrase, if it exists in the VM.
      -host    IP of the Virtual Machine.
      -id      Transaction id.

    list      List available patches for host.
      -key     Private SSH-key file to the Virtual Machine.
      -secret  Pass phrase, if it exists in the VM.
      -host    IP of the Virtual Machine.

  Command:
    oracle-dbcs-cli patch apply -key <key> -host <host> -id <patch_id> \
        [-secret <pass phrase>] [-force]
    oracle-dbcs-cli patch check -key <key> -host <host> -id <patch_id> \
        [-secret <pass phrase>] [-force]
    oracle-dbcs-cli patch rollback -key <key> -host <host> -id <patch_id> \
        [-secret <pass phrase>]
    oracle-dbcs-cli patch status -key <key> -host <host> -id <txn_id> \
        [-secret <pass phrase>]
    oracle-dbcs-cli patch list -key <key> -host <host> [-secret <pass phrase>]


  Example:
    $ oracle-dbcs-cli patch list -key key.pub -host 192.168.1.30
    Database Cloud Orchestration Tool:Release 2.0.30.12.00 on Wed Feb 04 15:19:40 PST 2015
    Copyright ©2014,2015, Oracle. All rights reserved.

    {
      "last_async_precheck_txn_id": " ",
      "last_async_apply_txn_id": " ",
      "err": "-1",
      "errmsg": "no applicable patches found",
      "current_version": "12.1.0.2.2",
      "last_async_precheck_patch_id": "",
      "current_patch": "",
      "last_async_apply_patch_id": "",
      "patches": []
    }
    DBOrch execution ended.


Template File
-------------
The file dboplan.dat.tmpl contains the necessary parameters to create a virtual
machine. Don't modify the template directly, make a copy such as dboplan.dat.

The file.cfg needs to contain: sm_url, user_name, password and
identity_domain. These parameters are also set on the dboplan.dat.tmpl
